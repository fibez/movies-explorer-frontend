const BEAT_FILM_API_URL = 'https://api.nomoreparties.co/beatfilm-movies';
const BEAT_FILM_BASE_URL = 'https://api.nomoreparties.co';

export { BEAT_FILM_API_URL, BEAT_FILM_BASE_URL };
